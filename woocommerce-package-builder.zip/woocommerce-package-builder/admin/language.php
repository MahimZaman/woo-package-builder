<?php


$words = array(
    __('January', 'woocommerce-package-builder'),
    __('February', 'woocommerce-package-builder'),
    __('March', 'woocommerce-package-builder'),
    __('April', 'woocommerce-package-builder'),
    __('May', 'woocommerce-package-builder'),
    __('June', 'woocommerce-package-builder'),
    __('July', 'woocommerce-package-builder'),
    __('August', 'woocommerce-package-builder'),
    __('September', 'woocommerce-package-builder'),
    __('October', 'woocommerce-package-builder'),
    __('November', 'woocommerce-package-builder'),
    __('December', 'woocommerce-package-builder'),
    __('completed', 'woocommerce-package-builder'),
    __('processing', 'woocommerce-package-builder'),
    __('on hold', 'woocommerce-package-builder'),
);